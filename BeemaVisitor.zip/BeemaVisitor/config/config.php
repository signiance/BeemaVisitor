<?php

// set environment

// if $_SERVER['HTTP_HOST'] is localhost:8888 development else production
if($_SERVER['HTTP_HOST'] == 'localhost:8888'){
    define('ENVIRONMENT', 'local');
}else if($_SERVER['HTTP_HOST'] == 'dev-beema.iru.gov.kw'){
    define('ENVIRONMENT', 'development');
}else{
    define('ENVIRONMENT', 'production');
}

// set base url if environment is development
if (ENVIRONMENT == 'local') {
    define('BASE_URL', 'http://localhost:8888/BeemaVisitor/');
    define('API_URL', 'http://localhost:8888/Beema/');
}
else if (ENVIRONMENT == 'development') {
    define('BASE_URL', 'https://dev-beema.iru.gov.kw/');
    define('API_URL', 'https://dev-beema.iru.gov.kw/');
}
else{
    define('BASE_URL', 'http://beema-uat.eba-utt4y3wz.me-south-1.elasticbeanstalk.com/');
    define('API_URL', 'https://beema.iru.gov.kw/');
}

// set lang using cookie
if (isset($_GET['lang'])) {
    $lang = $_GET['lang'];
    setcookie('lang', $lang, time() + (86400 * 30), "/");
} else {
    if (isset($_COOKIE['lang'])) {
        $lang = $_COOKIE['lang'];
    } else {
        $lang = 'en';
    }
}
?>