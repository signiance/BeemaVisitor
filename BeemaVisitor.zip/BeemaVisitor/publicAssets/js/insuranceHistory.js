
    document.addEventListener("DOMContentLoaded", function() {
        // Datatables Responsive
		$("#datatables-reponsive").DataTable({
			responsive: true,
            // make sorting by issue date desc
            order: [[ 3, "desc" ]]
		});
    });
	



    $(document).ready(function(){
        $("#insuranceHistory").addClass("active");

        $("#renewInsurance").removeClass("active");
        // remove the active class from dashboard
        $("#dashboard").removeClass("active");
        // remove acive class from insuranceHistory
        
    });



    // ajax to fetch insurance history
    $(document).ready(function(){
        $.ajax({
            url: apiURL + "insuranceHistory",
            method: "POST",
            // get civilId, reqId and plateNumber from local storage
            data: {
                civilId: localStorage.getItem("civilId"),
                
            },
            success: function(data){
                var table = $('#datatables-reponsive').DataTable();
                for(var i = 0; i < data['result'].length; i++){
                    var URL = apiURL + 'downloadInsurancePDF?insuId=' + data['result'][i]['insuranceId'];
                    var file = '<a href="'+URL+'" class="btn btn-sm btn-primary" id="pdf"><i class="fa fa-file-pdf"></i>Download</a>'
                    table.row.add([
                        data['result'][i]['cid'],
                        data['result'][i]['issueDate'],
                        data['result'][i]['plateNumber'],
                        data['result'][i]['make'],
                        data['result'][i]['model'],
                        data['result'][i]['color'],
                        data['result'][i]['year'],
                        data['result'][i]['startDate'],
                        data['result'][i]['endDate'],
                        data['result'][i]['companyName'],
                        data['result'][i]['authCode'],
                        file
                    ]).draw(false);
                }
            },
        });
    });
