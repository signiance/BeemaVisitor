/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./src/**/*.{html,js,css}",
"./docs/**/*.{html,js,css}",
"./dist/**/*.{html,js,css}",
"./docs/css/*.{html,js,css}",
"./docs/css/**/*.{html,js,css}"],
  
 corePlugins: {
   preflight: false,
 },
 //prefix: 'tw-',
 important: true,
  
  theme: {
    extend: {},
  },
  plugins: [],
}
