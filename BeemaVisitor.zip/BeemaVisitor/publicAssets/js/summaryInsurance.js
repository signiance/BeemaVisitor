$(document).ready(function(){
    $("#renewInsurance").addClass("active");
    // remove the active class from dashboard
    $("#dashboard").removeClass("active");
    // remove acive class from insuranceHistory
    $("#insuranceHistory").removeClass("active");
});





	// add class in button on click
	$(document).ready(function() {
		$('#payNow').on('click', function() {
			$(this).addClass('one-time-click');
		});
        // tandcID to open modal popup
        $('#tandcID').on('click', function() {
            $('#tandCpop').modal('show');
        });

        // close modal closeMobileIDModal
        $('#closeMobileIDModal').on('click', function() {
            $('#tandCpop').modal('hide');
        });
	});

	
 





    // ajax call on page load to fetch the data based on civil id and plate number from local storage
    $(document).ready(function(){
        var civil_id = localStorage.getItem("civilId");
        var plate_number = localStorage.getItem("plateNumber");
        var reqId = localStorage.getItem("reqId");
        $.ajax({
            url : apiURL + "getInsuranceSummary",
            type: "POST",
            data: {
                civil_id: civil_id,
                plate_number: plate_number,
                reqId: reqId
            },
            success: function(data){                
                // Person Details
                $("#civilnumber").html(data['data']['civilId']);
                $("#name").html(data['data']['nameEn']);
                $("#nationality").html(data['data']['nationality_en']);
                $("#gender").html(data['data']['gender']);

                // Vehicle details
                $("#plateNumber").html(data['data']['plateNumber']);
                $("#platePurpose").html(data['data']['platePurposeType']);
                $("#make").html(data['data']['make']);
                $("#model").html(data['data']['model']);
                $("#yearOfManufacture").html(data['data']['yearOfManufacture']);
                $("#noOfPassenger").html(data['data']['numberOfPassengers']);
                $("#shape").html(data['data']['shape']);
                $("#color").html(data['data']['majorColor']);


                // Insurance details
                $("#totAddFee").html(data['data']['totalAdditionalFee']);
                $("#basicFee").html(data['data']['basicFee']);
                $("#issueDate").html(data['data']['issuedDate']);
                $("#dNumber").html(data['data']['documentNumber']);
                $("#eDay").html(data['data']['expiryDay']);
                $("#eDate").html(data['data']['expiryDate']);
                $("#sDay").html(data['data']['startDay']);
                $("#sDate").html(data['data']['startDate']);                                
                $("#gTotal").html(data['data']['grandTotal']);
                $("#gTotalinWords").html(number2word(data['data']['grandTotal']));
                $("#violationFee").html(data['data']['violationsFee']);                
                $("#passengerFee").html(data['data']['passengersFee']);
                $("#accidentFee").html(data['data']['accidentsFee']);                
                $("#CCfess").html(data['data']['cubicCapacityFee']);
                $("#adminsFee").html(data['data']['administrativeFee']);
                $("#cName").html(data['data']['name_en']);
                // add image in logo
                $("#logo").attr("src", "https://api.iru.gov.kw"+data['data']['photo']);
            }
        });
    });

    // function  to check checkmark is checked
    function checkCheckmark() {
        if ($('#TandC').is(':checked')) {
            if ($('#chc2').is(':checked')) {
                $('#payNow').removeAttr('disabled');
            }else {
                $('#payNow').attr('disabled', 'disabled');
            }
        }
         else {
            $('#payNow').attr('disabled', 'disabled');
        }
    } 
    


    // ajax call on click pay button
    $(document).ready(function(){   
        $('#payNow').attr('disabled', 'disabled');     
        $("#payNow").click(function(){
            var civil_id = localStorage.getItem("civilId");
            var plate_number = localStorage.getItem("plateNumber");
            var reqId = localStorage.getItem("reqId");            
            $.ajax({
                url: apiURL + "initiatePayment",
                type: "POST",
                data: {
                    civil_id: civil_id,
                    plate_number: plate_number,
                    reqId : reqId
                },
                success: function(data){
                    if(data['success']==true){
                        // redirect to URL 
                        window.location.href = data['result'];
                    }
                    else{
                        $('#error').html(data['result']);
                        console.log('Error... Try Again');
                    }
                }                
            });            
        });
    });



    // function number2word to convert kuwaiti dinar to words
    function number2word(number) {
        var words = new Array();
        words[0] = '';
        words[1] = 'One';
        words[2] = 'Two';
        words[3] = 'Three';
        words[4] = 'Four';
        words[5] = 'Five';
        words[6] = 'Six';
        words[7] = 'Seven';
        words[8] = 'Eight';
        words[9] = 'Nine';
        words[10] = 'Ten';
        words[11] = 'Eleven';
        words[12] = 'Twelve';
        words[13] = 'Thirteen';
        words[14] = 'Fourteen';
        words[15] = 'Fifteen';
        words[16] = 'Sixteen';
        words[17] = 'Seventeen';
        words[18] = 'Eighteen';
        words[19] = 'Nineteen';
        words[20] = 'Twenty';
        words[30] = 'Thirty';
        words[40] = 'Forty';
        words[50] = 'Fifty';
        words[60] = 'Sixty';
        words[70] = 'Seventy';
        words[80] = 'Eighty';
        words[90] = 'Ninety';
        words[100] = 'Hundred';
        words[1000] = 'Thousand';


        amount = number.toString();
        atemp = amount.split(".");
        number = atemp[0].split(",").join("");
        n_length = number.length;
        words_string = "";
        if (n_length <= 9) {
            var n_array = new Array(0, 0, 0, 0, 0, 0, 0, 0, 0);
            var received_n_array = new Array();
            for (var i = 0; i < n_length; i++) {

                received_n_array[i] = number.substr(i, 1);
            }
            for (var i = 9 - n_length, j = 0; i < 9; i++, j++) {
                n_array[i] = received_n_array[j];
            }
            for (var i = 0, j = 1; i < 9; i++, j++) {
                if (i == 0 || i == 2 || i == 4 || i == 7) {
                    if (n_array[i] == 1) {
                        n_array[j] = 10 + parseInt(n_array[j]);
                        n_array[i] = 0;
                    }
                }
            }
            value = "";
            for (var i = 0; i < 9; i++) {
                if (i == 0 || i == 2 || i == 4 || i == 7) {
                    value = n_array[i] * 10;
                } else {
                    value = n_array[i];
                }
                if (value != 0) {
                    words_string += words[value] + " ";
                }
                if ((i == 1 && value != 0) || (i == 0 && value != 0 && n_array[i + 1] == 0)) {
                    words_string += "Kuwaiti Dinar ";
                }
                if (i == 3 && value != 0 && (n_array[i + 1] != 0 && n_array[i + 2] != 0)) {
                    words_string += "Hundred and ";
                } else if (i == 3 && value != 0) {
                    words_string += "Hundred ";
                }
                if (i == 5 && value != 0 && n_array[i + 1] != 0) {
                    words_string += "Thousand and ";
                } else if (i == 5 && value != 0) {
                    words_string += "Thousand ";
                }
                if (i == 6 && value != 0) {
                    words_string += "Hundred ";
                }
            }
            // join kuwaiti dinar
            words_string += "Kuwaiti Dinar ";
            words_string = words_string.split("  ").join(" ");
        }

        if (atemp[1] != undefined) {
            // get the decimal part in words with hundredths            
            number = atemp[1].split(",").join("");
            n_length = number.length;
            if (n_length <= 9) {
                var n_array = new Array(0, 0, 0, 0, 0, 0, 0, 0, 0);
                var received_n_array = new Array();
                for (var i = 0; i < n_length; i++) {
                    received_n_array[i] = number.substr(i, 1);
                }
                for (var i = 9 - n_length, j = 0; i < 9; i++, j++) {
                    n_array[i] = received_n_array[j];
                }
                for (var i = 0, j = 1; i < 9; i++, j++) {
                    if (i == 0 || i == 2 || i == 4 || i == 7) {
                        if (n_array[i] == 1) {
                            n_array[j] = 10 + parseInt(n_array[j]);
                            n_array[i] = 0;
                        }
                    }
                }
                value = "";
                for (var i = 0; i < 9; i++) {
                    if (i == 0 || i == 2 || i == 4 || i == 7) {
                        value = n_array[i] * 10;
                    } else {
                        value = n_array[i];
                    }
                    if (value != 0) {
                        words_string += words[value] + " ";
                    }
                    if ((i == 1 && value != 0) || (i == 0 && value != 0 && n_array[i + 1] == 0)) {
                        words_string += "Kuwaiti Dinar ";
                    }
                    if (i == 3 && value != 0 && (n_array[i + 1] != 0 && n_array[i + 2] != 0)) {
                        words_string += "Hundred and ";
                    } else if (i == 3 && value != 0) {
                        words_string += "Hundred ";
                    }
                    if (i == 5 && value != 0 && n_array[i + 1] != 0) {
                        words_string += "Thousand and ";
                    } else if (i == 5 && value != 0) {
                        words_string += "Thousand ";
                    }
                    if (i == 6 && value != 0) {
                        words_string += "Hundred ";
                    }
                }
                // join kuwaiti dinar
                words_string += "fils ";
                words_string = words_string.split("  ").join(" ");
            }
        }
        return words_string;
    }





