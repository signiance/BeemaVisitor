
    $(document).ready(function(){
        $("#renewInsurance").addClass("active");
        // remove the active class from dashboard
        $("#dashboard").removeClass("active");
        // remove acive class from insuranceHistory
        $("#insuranceHistory").removeClass("active");
    });



	$(document).ready(function(){
		var reqId  = localStorage.getItem("reqId");
		$.ajax({
			url : apiURL + "insurancePaymentHistory",
			// get request id from local storage
			data: {requestId: reqId},			
			method: "POST",
			success: function(data){
				// check if data success is false then navigate to different page
				if(data['success'] == false){
					window.location.href = "<?php echo BASE_URL.$lang;?>/dashboard";
				}else if(data['result']['status'] == "Success" ){
					$('#nofcust').html(data['result']['name_en']);
					$('#amt1').html("KWD "+data['result']['amount']);

					$('#PNO').html(data['result']['paymentId']);
					$('#PDATE').html(data['result']['payDate']);

					$('#nofcust2').html(data['result']['name_en']);
					$('#civilID').html(data['result']['civilId']);
					$('#address').html(data['result']['address']);
					$('#city').html(data['result']['city']);
					$('#country').html(data['result']['country']);
					// EMail Mobile
					$('#EMail').html(data['result']['email']);
					$('#Mobile').html(data['result']['mobile']);


					   

					$('#PaID').html("Payment Id: "+data['result']['paymentId']);
					$('#TRID').html("Track Id: " + data['result']['trackId']);
					$('#Auth').html("Auth: " + data['result']['auth']);
					$('#PMODE').html("Payment Mode: " + data['result']['pmode']);

					$('#PLNO').html(data['result']['plateNumber']);
					$('#Make').html(data['result']['make']);
					$('#Model').html(data['result']['model']);
					$('#Color').html(data['result']['color']);
					$('#YEAR').html(data['result']['manufacture']);
					$('#total').html("KWD "+data['result']['amount']);
				}else{
					window.location.href = baseURL + "/paymentFailed";
				}
			}
		});
	});
