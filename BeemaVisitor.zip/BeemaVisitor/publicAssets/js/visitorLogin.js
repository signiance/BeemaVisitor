
		// jquery to show employee form and hide visitor form
		$(document).ready(function(){
			$("#employeeForm").addClass("d-none");
			$("#employeeDiv").click(function(){
				$("#didAuthForm").addClass("d-none");
				$("#employeeForm").removeClass("d-none");
				$("#visitorForm").addClass("d-none");
				$("#visitorDiv").removeClass("imgActive");		
				$("#employeeDiv").addClass("imgActive");			
			});
		});
		// jquery to show visitor form and hide employee form
		$(document).ready(function(){
			$("#visitorDiv").click(function(){
				$("#visitorForm").removeClass("d-none");
				$("#employeeForm").addClass("d-none");
				$("#employeeDiv").removeClass("imgActive");			
				$("#visitorDiv").addClass("imgActive");			
			});
		});
	

	
		// call ajax to send paci data to validate
		$(document).ready(function(){
			$("#didAuthForm").addClass("d-none");
			$("#paciBtn").click(function(){
				var paci = $("#paci").val();
				$.ajax({
                    // get api url from config file
					url: apiURL + "reQuestAuth",
					method: "POST",
					data: {civilID:paci},
					success: function(data){						
						if(data['result'] == "success"){
							// show modal to tell user to use mobile id
							$("#useMobileIdModal").modal("show");
							// show different form with button to check if user did authenticate
							$("#visitorForm").addClass("d-none");
							$("#didAuthForm").removeClass("d-none");	
							$('#visitorError').html();
						}
						else 
						{
							$('#visitorError').html(data['message']);
						}

					}
				});
			});
		});

		// call ajax on click resend-request
		$(document).ready(function(){			
			$("#resend-request").click(function(){
				var paci = $("#paci").val();
				$.ajax({
					url: apiURL + "reQuestAuth",
					method: "POST",
					data: {civilID:paci},
					success: function(data){						
						// read json response and check the result						
						if(data['result'] == "success"){
							// show modal to tell user to use mobile id
							$("#useMobileIdModal").modal("show");
							// show different form with button to check if user did authenticate
							$("#visitorForm").addClass("d-none");
							$("#didAuthForm").removeClass("d-none");
							$('#visitorError').html();					
						}
						else 
						{
							$('#visitorError').html(data['message']);
						}

					}
				});
			});
		});


		// on closeMobileIDModal click hide modal and show paci form
		$(document).ready(function(){
			$("#closeMobileIDModal").click(function(){
				$("#useMobileIdModal").modal("hide");				
			});
		});


		// call ajax to check if user did authenticate
		$(document).ready(function(){			
			$("#approvedBtn").click(function(){
				var paci = $("#paci").val();
				$.ajax({
					url: apiURL + "validateAuth",
					method: "POST",
					data: {civilID:paci},
					success: function(data){					
						console.log(data['message']);
						// read json response and check the result						
						if(data['result'] == "success"){							
							// store data in local storage
							localStorage.setItem("civilId", data['data']['civilId'])
							localStorage.setItem("gender", data['data']['gender'])
							localStorage.setItem("name_ar", data['data']['name_ar'])
							localStorage.setItem("name_en", data['data']['name_en'])
							localStorage.setItem("nationality_ar", data['data']['nationality_ar'])
							localStorage.setItem("nationality_en", data['data']['nationality_en'])
							localStorage.setItem("sessionToken", data['data']['sessionToken'])

							// redirect to next page
							window.location.href = baseURL + "/dashboard";
						}
						else 
						{
							// // // store data in local storage
							// localStorage.setItem("civilId", 297013101839)
							// localStorage.setItem("gender", 'M')
							// localStorage.setItem("name_ar", 'محمد')
							// localStorage.setItem("name_en", 'Mohammad Dawood Petlawad')
							// localStorage.setItem("nationality_ar", 'هندى')
							// localStorage.setItem("nationality_en", "Indian")
							// localStorage.setItem("sessionToken", 'ab0-123')

							// // // redirect to next page
							//  window.location.href = baseURL + "/dashboard";
							$('#authError').html(data['message']);
							checkPaciResponse();
						}

					}
				});
			});
		});



		function checkPaciResponse(){
		    var paci = $("#paci").val();
		    setTimeout(function(){
				$.ajax({
					url: apiURL + "validateAuth",
					method: "POST",
					data: {civilID:paci},
					success: function(data){					
						console.log(data['message']);
						// read json response and check the result						
						if(data['result'] == "success"){							
							// store data in local storage
							localStorage.setItem("civilId", data['data']['civilId'])
							localStorage.setItem("gender", data['data']['gender'])
							localStorage.setItem("name_ar", data['data']['name_ar'])
							localStorage.setItem("name_en", data['data']['name_en'])
							localStorage.setItem("nationality_ar", data['data']['nationality_ar'])
							localStorage.setItem("nationality_en", data['data']['nationality_en'])
							localStorage.setItem("sessionToken", data['data']['sessionToken'])

							// redirect to next page
							window.location.href = baseURL + "/dashboard";
						}
						else 
						{
						    //window.location.href = "https://<?//php echo $_SERVER['HTTP_HOST']; ?>/BeemaVisitor/dashboard.php";
						    $('#authError').html(data['message']);
						    checkPaciResponse();
						}

					}
				});
		    },5000);
		}

	// jquery to get username password and validate
	$(document).ready(function() {
		$('#companySignIn').on('click', function() {
			$("#didAuthForm").addClass("d-none");
			// get the username and password
			var username = $('#username').val();
			var password = $('#password').val();
			// check if username and password are empty
			if (username != '' && password != '') {
				// make the ajax call
				$.ajax({
					url: apiURL + "companyL0g1n",
					type: 'POST',
					data: {
						"username": username,
						"password": password
					},
					success: function(data) {
						// check if the response is success
						if (data['success'] == true) {							
							// clear local storage
							localStorage.clear();

							// set the session token in local storage
							localStorage.setItem('sessionToken', data['user']['token']);
							localStorage.setItem('company_name_en', data['user']['name_en']);
							localStorage.setItem('company_name_ar', data['user']['name_ar']);
							localStorage.setItem('CRN', data['user']['CRN']);
							localStorage.setItem('employee_name', data['user']['fullName']);
							localStorage.setItem('employee_id', data['user']['id']);
							localStorage.setItem('employee_email', data['user']['userEmail']);
							localStorage.setItem('cLogo', data['user']['photo']);
							localStorage.setItem('role', data['user']['adminRole']);
							localStorage.setItem('companyId', data['user']['companyId']);
							// redirect to the home page
							window.location.href = apiURL + "../BeemaCompany/en/dashboard";
						} else {
							// error
							$('#employeeError').html(data['message']);
						}
					}
				});
			} else {
				$('#employeeError').html('Please enter your username and password');
			}
		});	
	});
