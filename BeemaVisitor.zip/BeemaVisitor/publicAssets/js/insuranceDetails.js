 

    // jquery to get ajax response and display in slider__container-1
    $(document).ready(function () {
        $.ajax({
            url: apiURL + "getEntityData",
            type: "POST",
            success: function (data) {
                var html = '';
                $.each(data, function (key, item) {                  
                    html += '<div class="col">';
                    html += '<label class="item" style="border:0.1px solid lightgrey;margin:2px">';
                    html += '<input type="radio" name="entities" value="' + item['commercial_record_number'] + '" />';
                    html += '<img src="https://api.iru.gov.kw'+item['photo']+'" alt="'+item['name_en']+" "+item['domain']+" "+item['name_ar']+'" />';
                    html += '<b style="text-align: center !important;display: block;">' + item['name_en'] + '</b>';
                    html += '</label>';
                    html += '</div>';
                });
                $('#gallery').html(html);
                // randomize the order of the images
                var $gallery = $('#gallery');
                var $images = $gallery.find('label');
                $images.sort(function () {
                    return Math.round(Math.random()) - 0.5;
                });
                
                $gallery.html($images);
               
                // filter the images based on search input value on image alt
                $('#filter-search').on('keyup', function () {
                    var rex = new RegExp($(this).val(), 'i');
                    $('#gallery label').hide();
                    $('#gallery label').filter(function () {
                        return rex.test($(this).find('img').attr('alt'));
                    }).show();
                });
            },
            error: function (xhr, status, error) {
                console.log(xhr.responseText);
            }
        });
    });

    



		document.addEventListener("DOMContentLoaded", function() {
			// Datatables with Multiselect
			var datatablesMulti = $("#multi").DataTable({
				responsive: true,
                order: [[6, 'asc']],
				select: {
					style: "single",                    
				}                
			});
            datatablesMulti //Restricting the selection of rows
                .on('select', function (e, dt, type, indexes) {
                    //if column 0 is empty, then don't allow the row to be selected
                    if (datatablesMulti.cell(indexes, 0).data() == "") {
                        datatablesMulti.rows(indexes).deselect();
                    }
                })                      
		});

        // jquery to enable button if record selected in datatable and include 
        $(document).ready(function () {
            $("#renewIns").prop("disabled", true);
            $('#multi tbody').on('click', 'tr', function () {
                if ($(this).hasClass('selected')) {
                    $(this).removeClass('selected');
                    $("#renewIns").prop("disabled", true);
                }
                else {
                    $("#multi").DataTable.$('tr.selected').removeClass('selected');
                    $(this).addClass('selected');
                    // check if the column 0 is empty or not
                    if ($("#multi").DataTable().cell('.selected', 0).data() != "") {
                        $("#renewIns").prop("disabled", false);
                    }
                }
            });
        });

        // call ajax on page reload to get number of cars for civil Id
        $(document).ready(function () {
            var civilId = localStorage.getItem("civilId");
            if (civilId != "") {
                $.ajax({
                    type: "POST",
                    url : apiURL + "getVisitorCars",
                    data: { civilId: civilId },
                    success: function (data) 
                    {   console.log(data);
                        if(data['result']!="error"){
                            var table = $('#multi').DataTable();
                            $.each(data['Details'], function (index, value) {

                                // check the expiry date is less than 30 days
                                var expiryDate = new Date(value.expiryDate);
                                var today = new Date();
                                var diff = expiryDate.getTime() - today.getTime();
                                var days = Math.ceil(diff / (1000 * 3600 * 24));
                                
                                // add radio button if days is less than 30
                                if (days < 30 && days > 0) {                                
                                    table.row.add([
                                        '<input type="checkbox" name="renew" value="' + value.PlateNumber + '" />',
                                        '<span class="badge bg-warning">Renewable</span>',
                                        value.PlateNumber,
                                        value.Make,
                                        value.Model,
                                        value.Color,
                                        value.yearManufacture,
                                        value.expiryDate
                                    ]).draw(false);
                                }
                                else  if (days < 0 ) {                                
                                    table.row.add([
                                        '<input type="checkbox" name="renew" value="' + value.PlateNumber + '" />',
                                        '<span class="badge bg-danger">Expired</span>',
                                        value.PlateNumber,
                                        value.Make,
                                        value.Model,
                                        value.Color,
                                        value.yearManufacture,
                                        value.expiryDate
                                    ]).draw(false);
                                }
                                else{
                                    // the row should not be selectable
                                    table.row.add([
                                        '',
                                        '',
                                        value.PlateNumber,
                                        value.Make,
                                        value.Model,
                                        value.Color,
                                        value.yearManufacture,
                                        value.expiryDate
                                    ]).draw(false);
                                }
                            });
                        }else{
                            $('#getCarError').html(data['message']);
                        }
                    }
                });
            }
        });
	

        // jquery to check checkbox when datatable row is selected and uncheck when row is unselected
        $(document).ready(function () {            
            $('#multi tbody').on('click', 'tr', function () {
                var table = $('#multi').DataTable();
                var data = table.row(this).data();
                // uncheck all checkboxes
                $('input[type="checkbox"]').prop('checked', false);
                if (data[0] != "") {                    
                    if ($(this).hasClass('selected')) {
                        $(this).find('input[type="checkbox"]').prop('checked', true);
                        $(this).removeClass('selected');
                    }
                    else {
                        $(this).find('input[type="checkbox"]').prop('checked', false);
                        table.$('tr.selected').removeClass('selected');
                        $(this).addClass('selected');
                        
                    }
                }
            });
        });


      


		document.addEventListener("DOMContentLoaded", function() {
			$("#smartwizard-default-primary").smartWizard({
				theme: "default",
				showStepURLhash: false
			});
			
			$("#smartwizard-arrows-primary").smartWizard({
				theme: "arrows",
				showStepURLhash: false
			});
        });



    $(document).ready(function(){
        $("#renewInsurance").addClass("active");
        // remove the active class from dashboard
        $("#dashboard").removeClass("active");
        // remove acive class from insuranceHistory
        $("#insuranceHistory").removeClass("active");
    });



    // validateEmail
    function validateEmail(email) {
        var re = /\S+@\S+\.\S+/;
        return re.test(email);
    }
    
    // function to validate mobile number
    function validateMobile(mobile) {
        var re = /^[0-9]{8}$/;
        // first digit should not be 9,6,5
        if(mobile.charAt(0) == 9 || mobile.charAt(0) == 6 || mobile.charAt(0) == 5 || mobile.charAt(0) == 4 || mobile.charAt(0) == 2){
            return re.test(mobile);
        }else{
            return false;
        }
    }



    // jquery to call ajax using platenumber and get response
    $(document).ready(function(){
        $(".sw-btn-next"). attr("id", "nextBtn");
        $(".sw-btn-prev"). attr("id", "prevBtn");
        $('#detailsForm').addClass('d-none');
        $("#renewIns").click(function(){

            // get the selected record from datatable
            var selectedRecord = $('#multi').DataTable().rows('.selected').data();

            // get platenumber from selected record
            var plateNumber = selectedRecord[0][2];
            var civilID = localStorage.getItem("civilId");
            var plateNumber = plateNumber;
            $.ajax({
                url : apiURL + "getData",
                method: "POST",
                data: {
                    plateNumber:plateNumber,
                    civilID:civilID
                },
                success: function(data){
                    if(data['result'] == "success"){
                        // hide the numberplateform and show the details form
                        $('#numberPlateForm').addClass('d-none');
                        $('#detailsForm').removeClass('d-none');
                        // fill the details form with the data

                        // tab content 1
                        $("#plateNo").html(data['vehicleDetails']['plateNumber']);
                        $("#platePurposeType").html(data['vehicleDetails']['platePurposeType']);
                        $("#vinNumber").html(data['vehicleDetails']['vinNumber']);
                        $("#make").html(data['vehicleDetails']['make']);
                        $("#model").html(data['vehicleDetails']['model']);
                        $("#yearOfManufacture").html(data['vehicleDetails']['yearOfManufacture']);
                        $("#numberOfPassengers").html(data['vehicleDetails']['numberOfPassengers']);
                        $("#shape").html(data['vehicleDetails']['shape']);
                        $("#majorColor").html(data['vehicleDetails']['majorColor']);
                        $("#weight").html(data['vehicleDetails']['weight']);
                        $("#height").html(data['vehicleDetails']['height']);
                        $("#cubicCapacity").html(data['vehicleDetails']['cubicCapacity']);
                        $("#towingPermitted").html(data['vehicleDetails']['towingPermitted']);
                        $("#minorColor").html(data['vehicleDetails']['minorColor']);


                        // tab content 2
                        $("#nameEn").html(data['customerDetails']['nameEn']);
                        $("#nameAr").html(data['customerDetails']['nameAr']);
                        $("#dob").html(data['customerDetails']['dob']);
                        $("#gender").html(data['customerDetails']['gender']);
                        $("#nationalityEn").html(data['customerDetails']['nationalityEn']);
                        $("#nationalityAr").html(data['customerDetails']['nationalityAr']);
                        $("#governate").html(data['customerDetails']['governate']);
                        $("#area").html(data['customerDetails']['area']);
                        $("#paciBno").html(data['customerDetails']['paciBNo']);
                        $("#requestId").html(data['insuranceDetails']['requestId']);
                        $("#blockNo").html(data['customerDetails']['block']);
                        $("#streetName").html(data['customerDetails']['street']);
                        $("#UnitNo").html(data['customerDetails']['unitNo']);


                        $("#frm2noplate").html(data['vehicleDetails']['plateNumber']);
                        $("#frm2make").html(data['vehicleDetails']['make']);
                        $("#frm2model").html(data['vehicleDetails']['model']);
                        $("#frm2color").html(data['vehicleDetails']['majorColor']);


                        // tab content 3
                        $("#prevCompcode").html(data['insuranceDetails']['currentCompanyCode']);
                        $("#prevCompName").html(data['insuranceDetails']['currentCompanyName']);
                        $("#documentNo").html(data['insuranceDetails']['currentDocumentNumber']);
                        $("#expiryDate").html(data['insuranceDetails']['currentExpiryDate']);
                        
                        
                        // $("#grandTotalInWords").html(data['insuranceDetails']['grandTotalInWords']);

                        //jquery to transform kuwaiti dinar to words                        
                        var amountInWords = number2word(data['insuranceDetails']['grandTotal']);
                        $("#grandTotalInWords").html(amountInWords);





                        $("#grandTotal").html(data['insuranceDetails']['grandTotal']);

                        $("#frm3noplate").html(data['vehicleDetails']['plateNumber']);
                        $("#frm3make").html(data['vehicleDetails']['make']);
                        $("#frm3model").html(data['vehicleDetails']['model']);
                        $("#frm3color").html(data['vehicleDetails']['majorColor']);
                    }else{
                        $('#getCarError').html(data['message']);
                    }

                    //$("#plateNumber").html(data);
                }
            });
        });
    });


    // function number2word to convert kuwaiti dinar to words
    function number2word(number) {
        var words = new Array();
        words[0] = '';
        words[1] = 'One';
        words[2] = 'Two';
        words[3] = 'Three';
        words[4] = 'Four';
        words[5] = 'Five';
        words[6] = 'Six';
        words[7] = 'Seven';
        words[8] = 'Eight';
        words[9] = 'Nine';
        words[10] = 'Ten';
        words[11] = 'Eleven';
        words[12] = 'Twelve';
        words[13] = 'Thirteen';
        words[14] = 'Fourteen';
        words[15] = 'Fifteen';
        words[16] = 'Sixteen';
        words[17] = 'Seventeen';
        words[18] = 'Eighteen';
        words[19] = 'Nineteen';
        words[20] = 'Twenty';
        words[30] = 'Thirty';
        words[40] = 'Forty';
        words[50] = 'Fifty';
        words[60] = 'Sixty';
        words[70] = 'Seventy';
        words[80] = 'Eighty';
        words[90] = 'Ninety';
        words[100] = 'Hundred';
        words[1000] = 'Thousand';


        amount = number.toString();
        atemp = amount.split(".");
        number = atemp[0].split(",").join("");
        n_length = number.length;
        words_string = "";
        if (n_length <= 9) {
            var n_array = new Array(0, 0, 0, 0, 0, 0, 0, 0, 0);
            var received_n_array = new Array();
            for (var i = 0; i < n_length; i++) {

                received_n_array[i] = number.substr(i, 1);
            }
            for (var i = 9 - n_length, j = 0; i < 9; i++, j++) {
                n_array[i] = received_n_array[j];
            }
            for (var i = 0, j = 1; i < 9; i++, j++) {
                if (i == 0 || i == 2 || i == 4 || i == 7) {
                    if (n_array[i] == 1) {
                        n_array[j] = 10 + parseInt(n_array[j]);
                        n_array[i] = 0;
                    }
                }
            }
            value = "";
            for (var i = 0; i < 9; i++) {
                if (i == 0 || i == 2 || i == 4 || i == 7) {
                    value = n_array[i] * 10;
                } else {
                    value = n_array[i];
                }
                if (value != 0) {
                    words_string += words[value] + " ";
                }
                if ((i == 1 && value != 0) || (i == 0 && value != 0 && n_array[i + 1] == 0)) {
                    words_string += "Kuwaiti Dinar ";
                }
                if (i == 3 && value != 0 && (n_array[i + 1] != 0 && n_array[i + 2] != 0)) {
                    words_string += "Hundred and ";
                } else if (i == 3 && value != 0) {
                    words_string += "Hundred ";
                }
                if (i == 5 && value != 0 && n_array[i + 1] != 0) {
                    words_string += "Thousand and ";
                } else if (i == 5 && value != 0) {
                    words_string += "Thousand ";
                }
                if (i == 6 && value != 0) {
                    words_string += "Hundred ";
                }
            }
            // join kuwaiti dinar
            words_string += "Kuwaiti Dinar ";
            words_string = words_string.split("  ").join(" ");
        }

        if (atemp[1] != undefined) {
            // get the decimal part in words with hundredths            
            number = atemp[1].split(",").join("");
            n_length = number.length;
            if (n_length <= 9) {
                var n_array = new Array(0, 0, 0, 0, 0, 0, 0, 0, 0);
                var received_n_array = new Array();
                for (var i = 0; i < n_length; i++) {
                    received_n_array[i] = number.substr(i, 1);
                }
                for (var i = 9 - n_length, j = 0; i < 9; i++, j++) {
                    n_array[i] = received_n_array[j];
                }
                for (var i = 0, j = 1; i < 9; i++, j++) {
                    if (i == 0 || i == 2 || i == 4 || i == 7) {
                        if (n_array[i] == 1) {
                            n_array[j] = 10 + parseInt(n_array[j]);
                            n_array[i] = 0;
                        }
                    }
                }
                value = "";
                for (var i = 0; i < 9; i++) {
                    if (i == 0 || i == 2 || i == 4 || i == 7) {
                        value = n_array[i] * 10;
                    } else {
                        value = n_array[i];
                    }
                    if (value != 0) {
                        words_string += words[value] + " ";
                    }
                    if ((i == 1 && value != 0) || (i == 0 && value != 0 && n_array[i + 1] == 0)) {
                        words_string += "Kuwaiti Dinar ";
                    }
                    if (i == 3 && value != 0 && (n_array[i + 1] != 0 && n_array[i + 2] != 0)) {
                        words_string += "Hundred and ";
                    } else if (i == 3 && value != 0) {
                        words_string += "Hundred ";
                    }
                    if (i == 5 && value != 0 && n_array[i + 1] != 0) {
                        words_string += "Thousand and ";
                    } else if (i == 5 && value != 0) {
                        words_string += "Thousand ";
                    }
                    if (i == 6 && value != 0) {
                        words_string += "Hundred ";
                    }
                }
                // join kuwaiti dinar
                words_string += "fils ";
                words_string = words_string.split("  ").join(" ");
            }
        }
        return words_string;
    }


    // function to check the required fields
    function checkRequiredFields(){
        var url = window.location.href;
        var value = url.substring(url.indexOf('#') + 1);
        if(value=='arrows-primary-step-2'){
            var mobile = $("#mobile").val();
            var email = $("#email").val();
            var profession = $("#profession").val();
            if(mobile == "" || email == "" || profession == ""){
                if(mobile == ""){
                    $("#mobileError").html("Mobile number is required");
                }else{
                    $("#mobileError").html("");
                }
                if(email == ""){
                    $("#emailError").html("Email is required");
                }else{
                    $("#emailError").html("");
                }
                if(profession == ""){
                    $("#professionError").html("Profession is required");
                }else{
                    $("#professionError").html("");
                }
                // disable next button
                $("#nextBtn").attr("disabled", true);
                $("#prevBtn").attr("disabled", true);
                return false;                    
            }else{
                if(!validateEmail(email)){
                    $("#emailError").html("Invalid email");
                    $("#nextBtn").attr("disabled", true);
                    $("#prevBtn").attr("disabled", true);
                }else if(!validateMobile(mobile)){
                    $("#mobileError").html("Invalid mobile number");
                    $("#nextBtn").attr("disabled", true);
                    $("#prevBtn").attr("disabled", true);
                }else{
                    $("#emailError").html("");
                    $("#mobileError").html("");
                    $("#professionError").html("");
                    $("#nextBtn").attr("disabled", false);
                    $("#prevBtn").attr("disabled", false);
                }
            }
        }
    }

    // jquery to show error if mobile number or email is empty on next button click
    $(document).ready(function(){        
        checkRequiredFields();
        $("#nextBtn").click(function(){
            checkRequiredFields();
        });
        $("#prevBtn").click(function(){
            checkRequiredFields();
        });

        $("#mobile").change(function(){
            checkRequiredFields();
        });

        $("#email").change(function(){
            checkRequiredFields();
        });

        $("#profession").change(function(){
            checkRequiredFields();
        });
    });






    // jquery to get #value from URL
    $(document).ready(function(){
        // on click next button
        $("#nextBtn").click(function(){
            var url = window.location.href;
            // get the value after #
            var value = url.substring(url.indexOf('#') + 1);
            if(value=='arrows-primary-step-3')
            {
                // add new button 
                $('#nextBtn').html('Review Insurance');
                $('#nextBtn').attr('id', 'submitBtn');             
                $('#submitBtn').removeClass('disabled');
            }
            else{
                $('#nextBtn').removeClass('disabled');
                $('#nextBtn').html('Next');
                $('#nextBtn').attr('id', 'nextBtn');
            }
        });
        $("#prevBtn").click(function(){
            var url = window.location.href;            
            // get the value after #
            var value = url.substring(url.indexOf('#') + 1);
            if(value=='arrows-primary-step-3')
            {
                // add new button                 
                $('#nextBtn').attr('id', 'submitBtn');
                $('#submitBtn').html('Review Insurance');
                $('#submitBtn').removeClass('disabled');
            }
            else{
                $('#submitBtn').removeClass('disabled');
                $('#submitBtn').html('Next');
                $('#submitBtn').attr('id', 'nextBtn');
            }
        });
    }); 



    // jquery to get value and call ajax function on click submitBtn
    $(document).ready(function(){
        $('#nextBtn').click(function(){
            // get value from entities radio button selected
            var entities = $("input[name='entities']:checked").val();
            // check value of email, profession,email and entities
            var email = $('#email').val();
            var profession = $('#profession').val();
            var mobile = $('#mobile').val();

            if(email == "" || !validateEmail(email)){
                $('#formErrorlst').html('Please fill the email field with a valid email');
            }else if(profession == ""){
                $('#formErrorlst').html('Please fill the profession field');
            }else if(mobile == "" || !validateMobile(mobile)){
                $('#formErrorlst').html('Please fill the mobile field with a valid mobile number');
            }else if(entities == undefined){
                $('#formErrorlst').html('Please select entities');
            }else{
                $('#formErrorlst').html('');
                // call ajax function
                ajaxCall(email,profession,mobile,entities);
            }
        });
    });

    // ajax function
    function ajaxCall(email,profession,mobile,entities){
        // get plateNo from label
        var plateNumber = $('#plateNo').text();        
        localStorage.setItem("plateNumber", plateNumber);                
        var reqId = $('#requestId').text();
        localStorage.setItem("reqId", reqId);
        // get civilId value        
        var civilId = localStorage.getItem("civilId");

        $customer = [
            ''
        ];

        $.ajax({
            url : apiURL + "addInsuranceDetails",
            type: 'POST',
            data: {email:email,profession:profession,mobile:mobile,companycode:entities, reqId:reqId, civilId:civilId},
            success: function(data){
                // if success true navigate to payment url
                if(data['success']==true)
                {
                    // redirect to URL 
                    window.location.href = 'summaryInsurance';
                }else{
                    $('#formErrorlst').html('Error... Try Again');
                }
            }
        });
    }



 $(document).ready(function(){
    $(window).scrollTop(0);
});
