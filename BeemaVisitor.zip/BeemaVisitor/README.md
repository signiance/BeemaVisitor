# Beema - Responsive Bootstrap 5 Admin & Dashboard Template

Thanks for buying. Navigate to `docs/docs-getting-started.html` to get started.
